#!/bin/bash


gmssl pbkdf2 -pass 1234 -salt 1122334455667788 -iter 60000 -outlen 16

